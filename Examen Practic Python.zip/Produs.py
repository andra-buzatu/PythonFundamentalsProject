class Produs:
    def __init__(self, nume, stoc, pret):
        self.nume = nume
        self.stoc = stoc
        self.pret = pret
