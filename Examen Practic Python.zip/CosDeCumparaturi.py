class CosDeCumparaturi:
    def __init__(self, lista_de_produse):
        self.lista_de_produse = list(lista_de_produse)

    def elibereaza_bon(self, lista_produse, nume_client, stoc_magazin):
        with open(f'./Bonuri/Bon_Fiscal_{nume_client}.txt', 'w') as writefile:
            total = 0.0
            writefile.write('BON FISCAL\n')
            for pos, i in enumerate(self.lista_de_produse):
                for j, aliment in enumerate(stoc_magazin):
                    if i[0] == stoc_magazin[j].nume:
                        writefile.write(f'{stoc_magazin[j].nume},{i[1]},'
                                        f'{i[1]*stoc_magazin[j].pret} lei')
                        total += i[1]*stoc_magazin[j].pret
                        if pos < len(self.lista_de_produse):
                            writefile.write('\n')
            writefile.write(f'PRET TOTAL,{total} lei')

    def adauga_produs(self, nume, cantitate):
        self.lista_de_produse.append([nume, cantitate])
