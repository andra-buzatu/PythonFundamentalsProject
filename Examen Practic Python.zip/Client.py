class Client:
    def __init__(self, buget, lista_produse):
        self.buget = buget
        self.lista_produse = lista_produse

    def plateste(self, stoc_magazin):
        for i, produs in enumerate(self.lista_produse):
            ok = False
            for j, aliment in enumerate(stoc_magazin):
                if produs[0] == stoc_magazin[j].nume:
                    ok = True
            if ok is False:
                del self.lista_produse[i]
        for i, produs in enumerate(self.lista_produse):
            ok = False
            for j, aliment in enumerate(stoc_magazin):
                if self.lista_produse[i][0] == aliment.nume:
                    if self.buget >= aliment.pret*self.lista_produse[i][1]:
                        if self.lista_produse[i][1] <= aliment.stoc:
                            ok = True
                            self.buget -= aliment.pret*self.lista_produse[i][1]
                            aliment.stoc -= self.lista_produse[i][1]
                            if aliment.stoc == 0:
                                del stoc_magazin[j]
            if ok is False:
                del self.lista_produse[i]


