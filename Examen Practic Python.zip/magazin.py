from Client import Client
from CosDeCumparaturi import CosDeCumparaturi
from Produs import Produs
import os
import shutil

if os.path.exists('./Bonuri'):
    shutil.rmtree('./Bonuri')
os.mkdir('./Bonuri')

stoc_magazin = []
sursa_stoc = input('Introduceti numele fisierului ce contine stocul magazinului: ')
if '.txt' in sursa_stoc:
    sursa_stoc = sursa_stoc[:-4]

with open(f'{sursa_stoc}.txt', 'r') as readfile:
    for row in readfile.readlines():
        row = row.split(sep=',')
        row[2].strip('\n')
        stoc_magazin.append(Produs(row[0], int(row[1]), int(row[2])))

sursa_liste_cumparaturi = input('Introduceti numele folderului ce contine listele de cumpraturi: ')
fisiere_liste = os.listdir(sursa_liste_cumparaturi)
for fisier in fisiere_liste:
    a = CosDeCumparaturi([])
    with open(f'./{sursa_liste_cumparaturi}/{fisier}', 'r') as readfile:
        buget = int(readfile.readline())
        numeClient = f'{fisier[:-4]}'
        for row in readfile.readlines():
            row = row.split(sep=',')
            nume = row[0]
            cantitate = int(row[1])
            a.adauga_produs(nume, cantitate)
        client = Client(buget, a.lista_de_produse)

    client.plateste(stoc_magazin)

    CosDeCumparaturi.elibereaza_bon(a, client.lista_produse, numeClient, stoc_magazin)
